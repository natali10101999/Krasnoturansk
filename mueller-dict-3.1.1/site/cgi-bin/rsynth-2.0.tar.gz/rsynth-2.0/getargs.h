/* $Id: getargs.h,v 1.13 1994/11/08 13:30:50 a904209 Exp a904209 $
*/
extern int getargs PROTO((char *module,int argc,char *argv[],...));
extern int help_only;
