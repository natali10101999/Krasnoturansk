char *Revision = "Revision: 2.0";
static char *ident = "@(#)say 2.0 94/11/08"; /* so 'what' works */
